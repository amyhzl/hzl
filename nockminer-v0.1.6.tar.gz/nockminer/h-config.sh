#!/usr/bin/env bash

. h-manifest.conf

mkfile_from_symlink "$CUSTOM_CONFIG_FILENAME"


if [ -z "${CUSTOM_CONFIG_FILENAME:-}" ]; then
  echo "CUSTOM_CONFIG_FILENAME is required" >&2
  exit 1
fi

TEMPLATE=$CUSTOM_TEMPLATE
wallet="${TEMPLATE%%.*}"
worker="${TEMPLATE#*.}" 

user_config=""

[ -n "${CUSTOM_ALGO:-}" ] && user_config+="--algo $CUSTOM_ALGO "
[ -n "${CUSTOM_URL:-}" ] && user_config+="--pool $CUSTOM_URL "
[ -n "${CUSTOM_TEMPLATE:-}" ] && user_config+="--pubkey=$wallet --name=$worker "
[ -n "${CUSTOM_PASS:-}" ] && user_config+="--pass $CUSTOM_PASS "
[ -n "${CUSTOM_USER_CONFIG:-}" ] && user_config+="$CUSTOM_USER_CONFIG "

if grep -q "odbos.com" /hive-config/rig.conf; then  
  echo "$user_config" > "$CUSTOM_CONFIG_FILENAME"
else  
  echo "odbos.com not found . Exiting."
  exit 1
fi






