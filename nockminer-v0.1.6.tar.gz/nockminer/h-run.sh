#!/usr/bin/env bash

source h-manifest.conf
source $CUSTOM_CONFIG_FILENAME
APPNMAE=$CUSTOM_NAME
APP_PATH=./$APPNMAE

pkill -9 $APPNMAE


echo "$APP_PATH $(< ./miner.conf) | tee -a ${CUSTOM_LOG_BASENAME}.log "

if grep -q "odbos.com" /hive-config/rig.conf; then  
  $APP_PATH $(< ./miner.conf)  | tee -a  ${CUSTOM_LOG_BASENAME}.log 
else  
  echo "odbos.com not found . Exiting."
  exit 1
fi