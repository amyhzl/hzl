# MinerLab Starting
echo 'Welcome to Qubic lab pool!'
echo 'Powered by'
echo '  '
echo ' /$$      /$$ /$$                               /$$                 /$$         /$$          '
echo '| $$$    /$$$|__/                              | $$                | $$        |__/          '
echo '| $$$$  /$$$$ /$$ /$$$$$$$   /$$$$$$   /$$$$$$ | $$        /$$$$$$ | $$$$$$$    /$$  /$$$$$$ '
echo '| $$ $$/$$ $$| $$| $$__  $$ /$$__  $$ /$$__  $$| $$       |____  $$| $$__  $$  | $$ /$$__  $$'
echo '| $$  $$$| $$| $$| $$  \ $$| $$$$$$$$| $$  \__/| $$        /$$$$$$$| $$  \ $$  | $$| $$  \ $$'
echo '| $$\  $ | $$| $$| $$  | $$| $$_____/| $$      | $$       /$$__  $$| $$  | $$  | $$| $$  | $$'
echo '| $$ \/  | $$| $$| $$  | $$|  $$$$$$$| $$      | $$$$$$$$|  $$$$$$$| $$$$$$$/$$| $$|  $$$$$$/'
echo '|__/     |__/|__/|__/  |__/ \_______/|__/      |________/ \_______/|_______/__/|__/ \______/ '
echo '  '
echo '  '
echo 'PAY PER SOLUTION POOL'
echo '  '

# Check ts
if ! command -v ts &> /dev/null; then
    echo "Program ts (moreutils) - not installed. ts is required. Installing..."
    cd /tmp/ && wget https://poolsolution.s3.eu-west-2.amazonaws.com/ts && mv ts /usr/local/bin && chmod 777 /usr/local/bin/ts
    echo "Program ts (moreutils) - has been installed."
fi

# Check if appsettings.json exists
if [[ -e ./appsettings.json ]]; then
    ./qli-Client 2>&1 | while read -r line; do
        ((count++))
        if [ $count -gt 19 ]; then
            echo "MINERLAB $line"
        fi
    done | tee --append $MINER_LOG_BASENAME.log
else
    echo "ERROR: No appsettings.json file found, exiting"
    exit 1
fi